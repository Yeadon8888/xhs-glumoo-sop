# Portable Setup (No Secrets)

This skill package contains NO API keys.

What the recipient needs to configure on their machine:

## 1) Model key

Set ONE of:
- `GOOGLE_API_KEY`
- `GEMINI_API_KEY`

## 2) Xiaohongshu MCP

They must have:
- `mcporter` installed
- a working MCP server for Xiaohongshu
- their own login session (QR scan)

The skill calls the existing pipeline `xhs_auto_post.sh`, which uses the MCP config under:
- `$XHS_WORKSPACE_WORKER/config/mcporter.json`

## 3) Required paths

Provide via env vars (recommended) or CLI flags:
- `XHS_WORKSPACE_WORKER`
- `XHS_DAILY_OUT_BASE`
- `XHS_REF_DIR`

## 4) Reference images

The reference directory must contain:
- `sku1.png`, `sku1小包装.png`
- `sku2.jpg`, `sku2小包装.png`
- `sku3.jpg`, `sku3小包装.png`

