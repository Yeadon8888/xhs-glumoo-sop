---
name: xhs-glumoo-sop
description: Run the Glumoo Xiaohongshu SOP end-to-end (copy+prompts -> image gen using real SKU refs -> send Feishu review -> publish to Xiaohongshu as only-me -> write report). Includes constraints: 🇲🇾 title prefix, cover badge, Malaysia scenes (indoor+outdoor), multi-image pet consistency.
---

# XHS Glumoo SOP

This skill packages the Glumoo Xiaohongshu SOP so others can reuse it.

## What it does

- Generates post copy + image prompts via the factory script.
- Generates images via Nano Banana Pro **using real SKU reference images**.
- Sends copy + images to Feishu for human review.
- After explicit approval, publishes to Xiaohongshu (visibility: only me) via MCP.
- Writes a markdown sending report.

## Paths (cross-machine)

This skill is designed to be portable. You provide paths via env vars or CLI flags.

Defaults (can be overridden):

- `XHS_WORKSPACE_WORKER` (default: `/Users/Apple/.openclaw/workspace-worker-xhs`)
- `XHS_DAILY_OUT_BASE` (default: `/Users/Apple/Documents/Glumoo/02_每日内容生成`)
- `XHS_REF_DIR` (default: `/Users/Apple/Documents/Glumoo/产品资料/产品照/三款产品`)

Derived from `XHS_WORKSPACE_WORKER`:
- Factory: `$XHS_WORKSPACE_WORKER/bundles/_unpacked/xhs_glumoo_pipeline/glumoo_factory_v4.6.1_FESTIVAL_FINAL.py`
- Image gen: `$XHS_WORKSPACE_WORKER/bundles/_unpacked/xhs_glumoo_pipeline/skills/nano-banana-pro/scripts/generate_image.py`
- Auto post: `$XHS_WORKSPACE_WORKER/bundles/_unpacked/xhs_glumoo_pipeline/xhs_auto_post.sh`
- MCP config: `$XHS_WORKSPACE_WORKER/config/mcporter.json`
- Reports dir: `$XHS_WORKSPACE_WORKER/reports`
- Media out: `$XHS_WORKSPACE_WORKER/media_out`

## Reference images

- SKU1: outer `sku1.png`, stick `sku1小包装.png` (box packaging)
- SKU2: outer `sku2.jpg`, stick `sku2小包装.png` (bag packaging)
- SKU3: outer `sku3.jpg`, stick `sku3小包装.png` (bag packaging)

## Creative constraints (must keep)

- Title must start with `🇲🇾`.
- Cover (image1) must include a fixed badge at bottom-right: `日本品牌｜大马制造`.
- Malaysia scenes must be recognizable; one set must include both indoor and outdoor scenes.
- Multi-image pet consistency: image1 defines appearance anchors.

## How to run

One-shot (generate for review only):

```bash
XHS_WORKSPACE_WORKER="/path/to/workspace-worker-xhs" \
XHS_DAILY_OUT_BASE="/path/to/02_每日内容生成" \
XHS_REF_DIR="/path/to/三款产品" \
python3 scripts/run_xhs_sop.py --content-type 科普 --sku 3 --theme "多宠家庭解决方案：一包搞定所有" --review-only
```

Auto rotate theme/sku/content_type by date (recommended for sharing):

```bash
XHS_WORKSPACE_WORKER="/path/to/workspace-worker-xhs" \
XHS_DAILY_OUT_BASE="/path/to/02_每日内容生成" \
XHS_REF_DIR="/path/to/三款产品" \
python3 scripts/run_xhs_sop.py --auto-theme --auto-sku --auto-content-type --themes-json ./config/themes.json --review-only
```

After approval (publish):

```bash
python3 scripts/run_xhs_sop.py --content-type 科普 --sku 3 --theme "多宠家庭解决方案：一包搞定所有" --publish
```

Notes:
- `--publish` assumes Xiaohongshu login is already valid.
- This skill does not bypass human review; it only publishes when `--publish` is used.
