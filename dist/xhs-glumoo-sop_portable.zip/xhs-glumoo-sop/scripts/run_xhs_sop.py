#!/usr/bin/env python3

import argparse
import datetime
import json
import os
import re
import subprocess
from pathlib import Path


def env_path(name: str, default: str) -> Path:
    return Path(os.environ.get(name, default)).expanduser()


SKILL_DIR = Path(__file__).resolve().parents[1]
DEFAULT_THEMES_JSON = SKILL_DIR / "config/themes.json"

WORKSPACE_WORKER = env_path("XHS_WORKSPACE_WORKER", "/Users/Apple/.openclaw/workspace-worker-xhs")
DAILY_OUT_BASE = env_path("XHS_DAILY_OUT_BASE", "/Users/Apple/Documents/Glumoo/02_每日内容生成")
REF_DIR = env_path("XHS_REF_DIR", "/Users/Apple/Documents/Glumoo/产品资料/产品照/三款产品")

FACTORY = WORKSPACE_WORKER / "bundles/_unpacked/xhs_glumoo_pipeline/glumoo_factory_v4.6.1_FESTIVAL_FINAL.py"
IMAGE_GEN = WORKSPACE_WORKER / "bundles/_unpacked/xhs_glumoo_pipeline/skills/nano-banana-pro/scripts/generate_image.py"
AUTO_POST = WORKSPACE_WORKER / "bundles/_unpacked/xhs_glumoo_pipeline/xhs_auto_post.sh"
MCP_CONFIG = WORKSPACE_WORKER / "config/mcporter.json"
REPORT_DIR = WORKSPACE_WORKER / "reports"
MEDIA_OUT_BASE = WORKSPACE_WORKER / "media_out"

SKU_REFS = {
    1: {"outer": REF_DIR / "sku1.png", "stick": REF_DIR / "sku1小包装.png", "pack": "box"},
    2: {"outer": REF_DIR / "sku2.jpg", "stick": REF_DIR / "sku2小包装.png", "pack": "bag"},
    3: {"outer": REF_DIR / "sku3.jpg", "stick": REF_DIR / "sku3小包装.png", "pack": "bag"},
}


def run(cmd, env=None, timeout=None):
    subprocess.check_call(cmd, env=env, timeout=timeout)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8").strip()


def split_tags_and_content(body: str):
    hashtags = re.findall(r"#\S+", body)
    tags = [h.lstrip("#") for h in hashtags if h.strip("#")]
    content = re.sub(r"\s*#\S+", "", body).strip()
    content = re.sub(r"\n{3,}", "\n\n", content)
    return tags, content


def safe_title(title: str) -> str:
    title = title.strip().replace("*", "")
    if not title.startswith("🇲🇾"):
        title = "🇲🇾" + title
    # Xiaohongshu title limits are strict (emoji/flags count heavier). Keep short.
    if len(title) > 14:
        title = title[:14]
    return title


def load_themes(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def pick_from_rotation(items, date_str: str):
    # Stable daily pick.
    d = datetime.date.fromisoformat(date_str)
    idx = d.toordinal() % len(items)
    return items[idx]


def choose_auto(theme_cfg: dict, date_str: str, content_type: str | None, sku: int | None):
    rotation = theme_cfg.get("rotation", {})

    if content_type is None:
        cts = rotation.get("content_types") or ["科普", "体验", "故事", "挑战", "转化"]
        content_type = pick_from_rotation(cts, date_str)

    if sku is None:
        skus = rotation.get("skus") or [3, 1, 2]
        sku = int(pick_from_rotation(skus, date_str))

    themes_map = theme_cfg.get("themes", {})
    candidates = themes_map.get(content_type) or ["多宠家庭解决方案：一包搞定所有"]
    theme = pick_from_rotation(candidates, date_str)

    return theme, content_type, sku


def find_latest_daily_folder(date_str: str, theme: str, sku: int, daily_out_base: Path) -> Path:
    # Factory writes to a folder containing date+theme+SKU.
    # Use glob to find the newest matching folder.
    patt = f"{date_str}_{theme}_SKU_{sku}_v4.6.1"
    candidates = sorted(daily_out_base.glob(patt), key=lambda p: p.stat().st_mtime, reverse=True)
    if not candidates:
        raise FileNotFoundError(f"No daily output folder found: {daily_out_base}/{patt}")
    return candidates[0]


def extract_prompt_blocks_from_text(text: str):
    # Either from refined prompt file, or from the正文 file after '### 绘图指令'.
    if "【绘图指令生成失败】" in text:
        return []

    parts = re.split(r"(?=\n\[图片\d+\])|(?=\A\[图片1/封面图\])", text)
    blocks = [p.strip() for p in parts if p.strip().startswith("[图片")]
    return blocks


def enforce_scene_rules(block: str, idx: int) -> str:
    block += "\n- 场景强制: 马来西亚可识别住宅/街区（铁花窗Grille/吊扇/复古花砖或水磨石/排屋车棚走廊/热带植物/强日照阴影，至少1-2项）"
    if idx == 1:
        block += "\n- 角标强制: 右下角固定角标/贴纸‘日本品牌｜大马制造’（清晰可读，位置固定）"
        block += "\n- 场景补充: 室内（马来西亚排屋客厅/餐区）"
    if idx == 2:
        block += "\n- 场景补充: 户外（排屋门口/车棚/走廊）"
    return block


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", default=datetime.date.today().strftime("%Y-%m-%d"))
    ap.add_argument("--theme")
    ap.add_argument("--auto-theme", action="store_true")
    ap.add_argument("--themes-json", default=str(DEFAULT_THEMES_JSON))

    ap.add_argument("--sku", type=int, choices=[1, 2, 3])
    ap.add_argument("--auto-sku", action="store_true")

    ap.add_argument("--content-type", default="科普", choices=["科普", "体验", "故事", "挑战", "转化"])
    ap.add_argument("--auto-content-type", action="store_true")

    ap.add_argument("--workspace-worker", default=str(WORKSPACE_WORKER))
    ap.add_argument("--daily-out-base", default=str(DAILY_OUT_BASE))
    ap.add_argument("--ref-dir", default=str(REF_DIR))

    ap.add_argument("--review-only", action="store_true")
    ap.add_argument("--publish", action="store_true")
    args = ap.parse_args()

    if args.review_only and args.publish:
        raise SystemExit("Choose one: --review-only or --publish")

    workspace_worker = Path(args.workspace_worker).expanduser()
    daily_out_base = Path(args.daily_out_base).expanduser()
    ref_dir = Path(args.ref_dir).expanduser()

    factory = workspace_worker / "bundles/_unpacked/xhs_glumoo_pipeline/glumoo_factory_v4.6.1_FESTIVAL_FINAL.py"
    image_gen = workspace_worker / "bundles/_unpacked/xhs_glumoo_pipeline/skills/nano-banana-pro/scripts/generate_image.py"
    auto_post = workspace_worker / "bundles/_unpacked/xhs_glumoo_pipeline/xhs_auto_post.sh"
    report_dir = workspace_worker / "reports"
    media_out_base = workspace_worker / "media_out"

    sku_refs = {
        1: {"outer": ref_dir / "sku1.png", "stick": ref_dir / "sku1小包装.png", "pack": "box"},
        2: {"outer": ref_dir / "sku2.jpg", "stick": ref_dir / "sku2小包装.png", "pack": "bag"},
        3: {"outer": ref_dir / "sku3.jpg", "stick": ref_dir / "sku3小包装.png", "pack": "bag"},
    }

    themes_cfg = load_themes(Path(args.themes_json)) if (args.auto_theme or args.auto_sku or args.auto_content_type) else None

    theme = args.theme
    content_type = args.content_type
    sku = args.sku

    if args.auto_content_type:
        content_type = None
    if args.auto_sku:
        sku = None
    if args.auto_theme:
        theme = None

    if themes_cfg is not None and (theme is None or content_type is None or sku is None):
        auto_theme, auto_ct, auto_sku = choose_auto(themes_cfg, args.date, content_type, sku)
        if theme is None:
            theme = auto_theme
        if content_type is None:
            content_type = auto_ct
        if sku is None:
            sku = auto_sku

    if theme is None:
        raise SystemExit("Missing --theme (or use --auto-theme)")
    if sku is None:
        raise SystemExit("Missing --sku (or use --auto-sku)")

    sku_ref = sku_refs[sku]
    if not sku_ref["outer"].exists():
        raise FileNotFoundError(f"Missing outer ref: {sku_ref['outer']}")
    if not sku_ref["stick"].exists():
        raise FileNotFoundError(f"Missing stick ref: {sku_ref['stick']}")

    # Step A: run factory
    env = os.environ.copy()
    env["CONTENT_TYPE"] = content_type
    run(["python3", str(factory)], env=env, timeout=300)

    out_dir = find_latest_daily_folder(args.date, theme, sku, daily_out_base)
    copy_path = out_dir / "01_正文与标签_复制即发.txt"
    prompt_path = out_dir / "02_生图提示词_中文精修.txt"

    copy_text = read_text(copy_path)
    copy_lines = copy_text.splitlines()
    title = safe_title(copy_lines[0] if copy_lines else "🇲🇾Glumoo")

    body = "\n".join(copy_lines[1:]).strip()
    body = re.split(r"\n---\n\n### 绘图指令", body, maxsplit=1)[0].strip()
    tags, content = split_tags_and_content(body)

    # Step B: prompts -> images
    prompt_text = read_text(prompt_path)
    blocks = extract_prompt_blocks_from_text(prompt_text)
    if not blocks:
        # fallback from copy file
        m = re.search(r"### 绘图指令[\s\S]*", copy_text)
        if m:
            blocks = extract_prompt_blocks_from_text(m.group(0))

    if not blocks:
        raise RuntimeError("No image prompt blocks available")

    out_media_dir = media_out_base / f"{args.date}_skill_{content_type}_SKU{sku}"
    out_media_dir.mkdir(parents=True, exist_ok=True)

    out_images = []
    for idx, blk in enumerate(blocks, 1):
        blk = enforce_scene_rules(blk, idx)
        fn = out_media_dir / ("01_cover_ref.png" if idx == 1 else f"{idx:02d}.png")
        run([
            "python3",
            str(image_gen),
            "--prompt",
            blk,
            "--input-image",
            str(sku_ref["outer"]),
            "--input-image",
            str(sku_ref["stick"]),
            "--filename",
            str(fn),
        ], timeout=1800)
        out_images.append(str(fn))

    # Step D/E: publish + report
    report_dir.mkdir(parents=True, exist_ok=True)

    report_path = report_dir / f"xhs_skill_report_{content_type}_SKU{sku}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
    report_path.write_text(
        "\n".join(
            [
                f"# XHS SOP Skill Report",
                "",
                f"- date: {args.date}",
                f"- theme: {theme}",
                f"- content_type: {content_type}",
                f"- sku: {sku}",
                f"- title: {title}",
                f"- copy: `{copy_path}`",
                f"- prompt: `{prompt_path}`",
                "",
                "## images",
                *[f"- `{p}`" for p in out_images],
                "",
                "## tags",
                f"- {json.dumps(tags, ensure_ascii=False)}",
            ]
        ),
        encoding="utf-8",
    )

    if args.publish:
        env2 = os.environ.copy()
        env2["XHS_TITLE"] = title
        env2["XHS_VISIBILITY"] = "仅自己可见"
        env2["XHS_CONTENT"] = content
        env2["XHS_TAGS_JSON"] = json.dumps(tags, ensure_ascii=False)
        env2["XHS_IMAGES_JSON"] = json.dumps(out_images, ensure_ascii=False)
        run(["bash", str(auto_post)], env=env2, timeout=600)

    print(str(report_path))


if __name__ == "__main__":
    main()
